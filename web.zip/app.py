from flask import Flask, render_template, request
import your_email_function_module  # Replace this with the module where your email sending function resides
import sqlite3


app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/send_email', methods=['POST'])
def send_email():
    if request.method == 'POST':
        customer_name = request.form['customer_name']
        customer_email = request.form['customer_email']
        email_sent = your_email_function_module.send_email(customer_email, customer_name)

        if email_sent:
            return "Email sent successfully with the unique coupon code!"
        else:
            return "Failed to send the email. Please check your mail configuration."

@app.route('/view_data')
def view_data():
    conn = sqlite3.connect('customer_coupons.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM CustomerCoupons")
    data = cursor.fetchall()
    conn.close()
    return render_template('view_data.html', data=data)


if __name__ == '__main__':
    app.run(debug=True)
